# Recorded LUT shaper experiment

Open report/report.md and its figures. results/ contains the combined 82-grid
screen and exact 12-grid full shortlist; confirmation/ contains fresh current-
source selected/baseline runs. All per-case metrics, axes, float32 vertex hashes
and solver diagnostics match exactly in the confirmation.

These are authoring-preview measurements, not a completed Buck2 execution.
Reproduce from the full source package:

    buck2 build //:lut_shaper_evaluation //:lut_shaper_report
    buck2 test //:lut_shaper_experiment_test //:lut_shaper_full_result_test

Numerical caches and elapsed-time identity are excluded from the contract.
The source package contains every referenced photographic sample and tool.
The fixed -2..64 winner is a measured compromise: the previous -4..64 grid
remains better on the predeclared balanced objective.
